package mathutils;

public class Addition {
    public int add(int a, int b) {
        return a + b;
    }
}

